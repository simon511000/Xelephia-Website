# Comment installer ?
1. Installation des dépendances de php : `composer install`
2. Installation des dépendances de javascript : `npm i`

Pour compiler automatiquement les fichiers js et scss : `npm run watch`