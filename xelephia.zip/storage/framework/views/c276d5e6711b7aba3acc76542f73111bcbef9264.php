<article id='tabs-<?php echo e($article->id); ?>'>
    <img src="/storage/<?php echo e($article->image); ?>" alt="Image">
    <p><?php echo e($article->description); ?></p>
    <div class="main-button">
        <a
            class="cursor-pointer"
            wire:click="addToCart(<?php echo e($article->id); ?>)"
        >
            Ajouter au panier (<?php echo e($article->getPrice()); ?>)
        </a>
    </div>
</article><?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/boutique-article.blade.php ENDPATH**/ ?>