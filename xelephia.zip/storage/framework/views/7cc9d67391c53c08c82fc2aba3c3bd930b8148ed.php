<ul class="nav nav-animate">
    <li class="scroll-to-section"><a href="#top" class="active">Jouer</a></li>
    <li class="scroll-to-section"><a href="#presentation">Presentation</a></li>
    <li class="scroll-to-section"><a href="#boutique">Boutique</a></li>
    <li class="scroll-to-section"><a href="#wiki">Wiki</a></li>
    <li class="scroll-to-section"><a href="https://discord.gg/TfWGYXx" target="_blank">Discord</a></li>
    <?php if(!$connected): ?>
        <li class="scroll-to-section cursor-pointer"><a data-toggle="modal" data-target="#connexionModal">Connexion</a></li>
        <li class="main-button"><a href="#" data-toggle="modal" data-target="#inscriptionModal">Inscription</a></li>
    <?php else: ?>
        <li class="main-button"><a><?php echo e($user->name); ?></a></li>
    <?php endif; ?>
</ul><?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>