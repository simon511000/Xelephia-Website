<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\xelephia\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>