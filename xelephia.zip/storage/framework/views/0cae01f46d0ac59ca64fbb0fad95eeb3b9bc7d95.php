<div>
    <button wire:click="test">Test</button>
</div>
<?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/test.blade.php ENDPATH**/ ?>