<section class="row">
    <div class="col-lg-6 offset-lg-3">
        <div class="section-heading">
            <h2>Notre <em>Boutique</em></h2>
            <img src="./images/line-dec.png" alt="">
            <p>C'est ici que vous pouvez échanger vos <em style="color:#f6861a" >Points Boutique</em> en échange de lots sur le serveur (Grades, Cosmétiques...)</p>
            <p>
                <label for="categorie-boutique">Catégorie : </label>
                <select id="categorie-boutique" wire:model="categorySelected">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </p>
        </div>
    </div>
    <div class="row tabs">
        <div class="col-lg-4">
            <div class="main-rounded-button"><a href="#">Mon panier (<?php echo e(Cart::count()); ?>)</a></div>
            <ul class="itemshop-list">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="cursor-pointer <?php if($articleSelected->id === $article->id): ?> ui-tabs-active ui-state-active <?php endif; ?>" wire:click="setArticleSelected(<?php echo e($article->id); ?>)"><a><?php echo e($article->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-lg-8">
            <div class='tabs-content'>
                <article>
                    <img src="/storage/<?php echo e($articleSelected->image); ?>" alt="Image">
                    <p wire:click="test"><?php echo e($articleSelected->description); ?></p>
                    <div class="main-button">
                        <a
                            class="cursor-pointer"
                            wire:click="ajouterPanier(<?php echo e($articleSelected->id); ?>)"
                        >
                            Ajouter au panier (<?php echo e($articleSelected->getPrice()); ?>)
                        </a>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/boutique-main.blade.php ENDPATH**/ ?>