<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<img src="http://xelephia.local/images/logo-rectangle.png" class="logo" alt="Logo de Xelephia">
</a>
</td>
</tr>
<?php /**PATH C:\laragon\www\xelephia\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>