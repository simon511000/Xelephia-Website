<p>
    <label for="categorie-boutique">Catégorie : </label>
    <select id="categorie-boutique" wire:model="categorySelected">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</p><?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/boutique/select.blade.php ENDPATH**/ ?>