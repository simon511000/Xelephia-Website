[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\laragon\www\xelephia\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>