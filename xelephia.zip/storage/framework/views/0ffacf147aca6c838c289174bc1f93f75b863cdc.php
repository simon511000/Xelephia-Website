<div>
    <div class="main-rounded-button"><a href="#">Mon panier (<?php echo e(Cart::count()); ?>)</a></div>
    <ul class="itemshop-list">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href='#tabs-<?php echo e($article->id); ?>'><?php echo e($article->title); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\laragon\www\xelephia\resources\views/livewire/boutique/sidebar.blade.php ENDPATH**/ ?>