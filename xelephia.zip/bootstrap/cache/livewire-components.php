<?php return array (
  'boutique-main' => 'App\\Http\\Livewire\\BoutiqueMain',
  'boutique.select' => 'App\\Http\\Livewire\\Boutique\\Select',
  'boutique.sidebar' => 'App\\Http\\Livewire\\Boutique\\Sidebar',
  'connexion-modal' => 'App\\Http\\Livewire\\ConnexionModal',
  'inscription-modal' => 'App\\Http\\Livewire\\InscriptionModal',
  'mot-de-passe-oublie-main' => 'App\\Http\\Livewire\\MotDePasseOublieMain',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
);